import bookmarkController from "./bookmark.controller";
import historyController from "./history.controller";
import userController from "./user.controller";

export { bookmarkController, historyController, userController };
