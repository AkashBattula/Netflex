import queryString from "query-string";

export default location => queryString.parse(location);
