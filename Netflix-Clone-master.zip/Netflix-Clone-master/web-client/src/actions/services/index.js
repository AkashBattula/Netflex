import movieService from "./movie.service";
import userService from "./user.service";
import searchService from "./search.service";

export { userService, searchService, movieService };
