const getError = state => state.errorReducer.error;

export default {
  getError
};
