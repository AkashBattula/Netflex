import React from "react";

const NotFoundMovie = () => (
  <div className="movie-page-title">Oops.. Movie Not Found.</div>
);

export default NotFoundMovie;
