import React from "react";

const LoadingMovie = () => (
  <div className="movie-page-title">Loading Movie...</div>
);

export default LoadingMovie;
