## Data Fetcher

### Getting Started

- install dependencies

```terminal
pip install -r requirements.txt
```

- fetch movie data from IMDB

```terminal
cd imdb_scraper
scrapy crawl "imdb_spider"
```
