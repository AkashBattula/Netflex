## Web Server

---

### Getting Started

- install dependencies & start Web Server

```terminal
cd web-server
npm install
npm start
```

Application will be serving on http://localhost:3030
